# Calculadora de média - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/SaldanhaX/pen/rNrPPoK](https://codepen.io/SaldanhaX/pen/rNrPPoK).

Projeto 1 da imersão dev